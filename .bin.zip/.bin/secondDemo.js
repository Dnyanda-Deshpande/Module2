/*********inheritance*************/
/*class AnimalJungle1
{
    favFood : string;
    name:string;
    owner:string;
    static numOfAnimals : number = 0;
    
    _weight : number
    constructor( name:string,  owner:string)
    {
        this.name=name;
        this.owner=owner;
        AnimalJungle1.numOfAnimals++;
        
    }
    ownerInfo()
    {
        document.write("<br>"+this.name+" is owned by "+this.owner+"<br>");
    }
    get weight():number
    {
        return this._weight;
    }
    set weight(w:number)
    {
        this._weight = w;
    }

}


var doggy = new AnimalJungle1("Janjir","Dnyanda");
doggy.weight=100;
console.log(doggy.weight);
console.log(AnimalJungle1.numOfAnimals);
doggy.ownerInfo();

var  doggy1 = new AnimalJungle1("Chinu","Dnyanda");
doggy1.weight=200;
console.log(doggy1.weight);
console.log(AnimalJungle1.numOfAnimals);
doggy1.ownerInfo();



class DomesticAnimal extends AnimalJungle1
{
    
    constructor(private _typeOfWork, name,  owner)
    {
        super(name, owner);
    }
    get typeOfWork():string
    {
        return this._typeOfWork;
    }
    set typeOfWork(w:string)
    {
        this._typeOfWork = w;
    }
    ownerInfo()
    {
        document.write("<br>"+this._typeOfWork+"<br>"+this.name+" is owned by "+this.owner+"<br>");
    }
}

var mani = new DomesticAnimal("sleep","chinu","dnynada");
mani.typeOfWork="eat";
console.log(mani.typeOfWork);
mani. ownerInfo();*/
class Car {
    constructor(wheels) {
        this.wheels = wheels;
    }
    dirve() {
        document.write("<br>the car dirves with " + this.wheels + "whels<br>");
    }
}
class Bicycle {
    constructor(wheels) {
        this.wheels = wheels;
    }
    dirve() {
        document.write("<br>the Bicycle dirves with " + this.wheels + "whels<br>");
    }
}
document.write("<br>============================<br>");
var car = new Car(4);
var bike = new Bicycle(2);
car.dirve();
bike.dirve();
