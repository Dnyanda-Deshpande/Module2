var Employee = (function () {
    function Employee() {
    }
    Employee.emppf = 12;
    Employee.company = 'CAPGEMINI';
    return Employee;
}());
var emp = new Employee();
emp.empId = 1001;
emp.empName = "Vikash";
emp.empsalary = 1111;
document.write("Id is " + emp.empId + " Name is  " + emp.empName + " company " + Employee.company);
