var AClass = /** @class */ (function () {
    function AClass() {
    }
    AClass.prototype.add = function (v1, V2) {
        return v1 + V2;
    };
    return AClass;
}());
var obj = new AClass();
console.log(obj.add(2, 2));
function GetType(val) {
    return typeof (val);
}
GetType(45);
