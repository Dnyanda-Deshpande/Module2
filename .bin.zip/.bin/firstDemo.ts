document.write("Hello world");

var myName : string = "Dnyanda";
var myAge : number = 32;
var canVote : boolean = true;
var anything : any = "Capgemini";

document.write("Hello");
document.getElementById("aa").innerHTML = "I am "+myName;

document.write("<br><br>"+"type of myName is "+typeof(myName));
document.write("<br><br>"+"type of myAge is "+typeof(myAge));
document.write("<br><br>"+"type of canVote is "+typeof(canVote));
document.write("<br><br>"+"type of anything is "+typeof(anything));

/*const PI = 3.14;
PI = 22;
document.write("<br>PI is a "+typeof(PI)+" "+PI);*/


/************Data types****************/
var strToNumber:number = parseInt("aa");
var numberToString:number=5;

document.write("<br>strToNumber is a "+ typeof(strToNumber)+" "+strToNumber);
document.write("<br>numberToString is a "+ typeof(numberToString)+" "+numberToString);



/******array********/
document.write("<br><br><br>");
var randomArray=[25,36,81,100,4];
for(var val of randomArray){
	document.write("Number "+val+"<br>");
}



/********map**********/
document.write("<br><br><br>");
var mappedArray = randomArray.map(Math.sqrt);
for(var val1 of mappedArray){
	document.write("Square root "+val1+"<br>");
}



/**********callback function************/
document.write("<br><br><br>");
function cal(n:number):number{
	return n*n;
}


var mappedArraySpr = randomArray.map(cal);
for(var val2 of mappedArraySpr){
	document.write("Square "+val2+"<br>");
}

/*var addOne=(x)=>
{
	return x+1;
}*/

var addOne=(x)=>x+1;
console.log(addOne(1));







/********functiopn**************/
var GetSum = function(num1:number,num2:number):number
{
	return num1+num2;
}

var ans:number = GetSum(2,2);

document.write("<br><br>Sum is :"+ans); 





/************reduce*******************/

var total = [2,3,5].reduce(
function(a,b)
{
	return a+b;
}
);

document.write("<br><br>"+total);

//arrow function
var total1 = [2,3,5].reduce((a,b)=>a+b);


document.write("<br><br>"+total1);



/*****************rest parameter*********************/
var sumAll = function(...nums:number[]):void
{	
	var sum = nums.reduce((a,b)=>a+b);
	document.write("<br><br>Sum :"+sum);
}

sumAll(4,4);
sumAll(4,5,6);
sumAll(1,2,3,4,5,6,7,8,9,10);




/**************************CLASS***************************/
class Employee11
{
	/*private*/ Name : string = "Dnyanda";
/*	getName() : string     //arrow function getName=()=>{return this.Name;}
	{
		return this.Name;
	}
	setName(name : string) : void    //arrow function setName=(name)=>{this.Name = name;}
	{
		this.Name = name;
	}*/

	 getName=()  :string  =>{return this.Name;}
	 setName=(name : string) : void =>{this.Name = name;} 
}


var e1 = new Employee11();
console.log(e1.getName());
//e1.setName("Doremi");
//console.log(e1.getName());
//console.log(e1.Name);

/*******class cars**********************/
class Cars1
{
	 IsInNetural : boolean;
	 speed : number;
	 startCar(IsInNetural) 
	 {
		if(IsInNetural==true)
		{
		 	console.log("Car Started....!!!!!");
		}
		else
		{
			console.log("Please Bring to netural Phase....!!");
		}
	 }
	 stopCar()
	 {
		 console.log("Car Stopped.....!!!!!");
	 }
	
	 IncreaseSpeed(speed) : number
	 {
		this.speed = speed + 10;
		return this.speed;
	 }
	 DecreseSpeed(speed) : number
	 {
		 this.speed = speed - 10;
		 return this.speed;
	 }
}

var polo = new Cars1();
polo.startCar(true);
polo.stopCar();
console.log(polo.IncreaseSpeed(100)); 
console.log(polo.DecreseSpeed(120));

/***********class TV*******************/
class TV
{
	manufacturer : string;
	size : number;
	MaxChannels : number;
	Price : number;
	DisplayType : string
	channelNo : number = 12;
	volume : number;
	
	constructor(Mname, TVSize, channel, TvPrice, TvDisplayType)
	{
		this.manufacturer = Mname;
		this.size = TVSize;
		this.MaxChannels = channel;
		this.Price = TvPrice;
		this.DisplayType = TvDisplayType;
		console.log("\nThe TV Manufactuere Is : "+this.manufacturer+"\nThe TV size is : "+this.size+" Inches"+"\nMaxChannels Are :  "+this.MaxChannels+"\nPrice Is : "+this.Price+"\nDisplay Type Is :  "+this.DisplayType);

	}
	/*getManufactuerr() : string    
	{
		console.log("The TV Manufactuere Is : "+this.manufacturer);
		return this.manufacturer;
	}
	setManufactuerr(Mname : string) : void  
	{
		this.manufacturer = Mname;
	}
	


	getSize() : number    
	{
		console.log("The TV size is "+this.size+" Inches");
		return this.size;
	}
	setSize(TVSize : number) : void  
	{
		this.size = TVSize;
	}
	

	getChannels() : number    
	{
		console.log("MaxChannels Are :  "+this.MaxChannels);
		return this.MaxChannels;
	}
	setChannels(channel : number) : void  
	{
		this.MaxChannels = channel;
	}



	getPrice() : number    
	{
		console.log("Price Is :  "+this.Price);
		return this.Price;
	}
	setPrice(TvPrice : number) : void  
	{
		this.Price = TvPrice;
	}


	
	getDisplayType() : string    
	{
		console.log("Display type Is :  "+this.DisplayType);
		return this.DisplayType;
	}
	setDisplayType(TvDisplayType : string) : void  
	{
		this.DisplayType = TvDisplayType;
	}*/

	
	On()
	{
		console.log("TV Started....!!!!!!");
	}



	Off()
	{
		console.log("TV Off....!!!!!!");
	}



	ChangeChannel(channelNumber : number) : number
	{
		this.channelNo = channelNumber;
		console.log("The new Channel Number Is : "+this.channelNo);
		return this.channelNo;
	}



	IncreaseVolume(volume) :number
	{
		this.volume = volume + 10;
		console.log("Volume Is Incresed...!!!!!!");
		return this.volume;
		
	}



	DecreaseVolume(volume) :number
	{
		this.volume = volume - 10;
		console.log("Volume Is Decresed...!!!!!!");
		return this.volume;
		
	}

}


var tele = new TV("ONIDA", 80, 722,25000, "3D");
console.log(tele);


/*tele.setManufactuerr("ONIDA");
tele.getManufactuerr();

tele.setSize(80);
tele.getSize();

tele.setChannels(772)
tele.getChannels();

tele.setPrice(25000)
tele.getPrice();

tele.setDisplayType("3D")
tele.getDisplayType();*/



tele.On();
tele.Off();
tele.ChangeChannel(20);
tele.IncreaseVolume(100);
tele.DecreaseVolume(200);


/****************************Property********************************/
//tsc filename -watch --target ES6
class Animal1
{
	favFood : string;
	static numOfAnimals : number = 0;
	
	_weight : number
	constructor(private name:string, private owner:string)
	{
		Animal.numOfAnimals++;
		
	}
	ownerInfo()
	{
		document.write("<br>"+this.name+" is owned by "+this.owner+"<br>");
	}
	get weight():number
	{
		return this._weight;
	}
	set weight(w:number)
	{
		this._weight = w;
	}

}


var dog = new Animal1("Janjir","Dnyanda");
dog.weight=100;
console.log(dog.weight);
console.log(Animal.numOfAnimals);
dog.ownerInfo();

var  dog1 = new Animal1("Chinu","Dnyanda");
dog1.weight=200;
console.log(dog1.weight);
console.log(Animal.numOfAnimals);
dog1.ownerInfo();



class DomesticAnimal extends Animal1
{
	constructor(private _typeOfWork, private name, private owner)
	{
		super(name, owner);
	}
	get typeOfWork():string
	{
		return this._typeOfWork;
	}
	set weight(w:string)
	{
		this._typeOfWork = w;
	}

}