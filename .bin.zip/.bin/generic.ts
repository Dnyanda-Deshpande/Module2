class AClass<T>
{
	add(v1:T, V2:T)
	{
		return v1+V2;
	}
}


var obj = new AClass<number>();
console.log(obj.add(2,2));



function GetType<T>(val:T):string
{
	return typeof(val);
}

GetType<number>(45);