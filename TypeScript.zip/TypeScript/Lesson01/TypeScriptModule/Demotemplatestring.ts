let ename:string = "TypeScript";
let greeting  = `Hello, ${ename}! Your name has ${ename.length} characters`;
console.log(greeting);
