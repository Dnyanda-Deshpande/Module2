
/**************FIRST NAME VALIDATION*******************/
function checkFName()
{
	var name=document.getElementById("fnameId").value;
	var len=name.length;
	if(len>10)
	{
		var fnameerr=document.getElementById("firstNamerr");
		fnameerr.innerHTML="Name must be max of 10 letters!";
		
	}
	else
	{
		var fnameerr=document.getElementById("firstNamerr");
		fnameerr.innerHTML="";
	}
	
}


/**************LAST NAME VALIDATION*******************/
function checkLName()
{
	var name=document.getElementById("lnameId").value;
	var len=name.length;
	if(len>10)
	{
		
		var lnameerr=document.getElementById("lastNameerr");
		lnameerr.innerHTML="The employee number should be correct.";
		
	}
	else
	{
		var lnameerr=document.getElementById("lastNameerr");
		lnameerr.innerHTML="";
	}
	
}

/**************EMAIL VALIDATION*******************/
function validateEmail()
      {
         var emailID = document.myFrm.emailSec.value;
		 len=emailID.length;
         atpos = emailID.indexOf("@");
         
         
         if (atpos < 1) 
         {
			var emailErr=document.getElementById("emailIderr");
			emailErr.innerHTML="Please enter correct email ID";
            
         }
		 else
		 {
			var emailErr=document.getElementById("emailIderr");
			emailErr.innerHTML="";
		 }
       
      }

	  
/**************CHECKBOX VALIDATION*******************/	  

/*function CheckedCB()
{
	var tick=0;
	var checkbox1=document.getElementById("hoby[]");
	var checkbox2=document.getElementById("hoby[]");
	var checkbox3=document.getElementById("hoby[]");
	var checkbox4=document.getElementById("hoby[]");
   // document.getElementById('CheckBox1').checked=true;
   for()
   if(checkbox.checked==false)
   {
		var checkBerr=document.getElementById("checkBoxErr");
		checkBerr.innerHTML="Please Select Checkbox";
	}
	else
	{
		var checkBerr=document.getElementById("checkBoxErr");
		checkBerr.innerHTML="";
	}
	
}*/

function CheckedCB() { 
		var CheckboxesTicked = 0 ;
		for (i =0; i<=( document.getElementsByName("hoby[]").length - 1); i++) { 
			if (document.getElementsByName("hoby[]")[i].checked==true) { 
				CheckboxesTicked++;
			} 
		} 
		if (CheckboxesTicked <2 ) { 
		
			var checkBerr=document.getElementById("checkBoxErr");
			checkBerr.innerHTML="Please choose at least two hobbies.";
			//alert ("Please choose at least two hobbies.") 

		} 
		else
		{
			var checkBerr=document.getElementById("checkBoxErr");
			checkBerr.innerHTML="";
			
			
			
				/*********************DATA CONFIRMATION*******************/		
				var txt;
				var r = confirm("Do you want to Submit data?");
				if (r == true) {
				 alert("Data submitted Suceessfully");
				}
				else {
					alert("You pressed cancel");
				}

					
		}
} 
		  

/**************EMP NO VALIDATION*******************/	  
function checkEmpNo()
{
	var str=document.getElementById("empNoId").value;
	var p=/^([A-Za-z]{3}[0-9]{3})$/;
	var res=str.match(p);
	if(res==null)
	{
		var Id=document.getElementById("errSectionId");
		Id.innerHTML="Wrong pattern!";
		return false;
	}
	else
	{
		var sub=str.substr(3);
		var res=(sub%7);
		if(res!=0)
		{
			var Id=document.getElementById("errSectionId");
			Id.innerHTML="Wrong pattern!";
			return false;
		}
		else
		{
			var Id=document.getElementById("errSectionId");
			Id.innerHTML="";
		}
	}
	return true;
	
}

