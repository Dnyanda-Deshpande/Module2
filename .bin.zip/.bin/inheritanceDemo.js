class Human {
    constructor(FN, LN, Age, Height) {
        this.FN = FN;
        this.LN = LN;
        this.Age = Age;
        this.Height = Height;
    }
    walk() {
        document.write("<br>Human is Walking.......!!!!!!!!<br>");
    }
    Talk() {
        document.write("<br>Human is Talkig.....!!!!!!!!!<br>");
    }
    Run() {
        document.write("<br>Human is Running.....!!!!!!!!!<br>");
    }
    ShowDetails() {
        document.write("<br>First Name : " + this.FN + "<br>Last Name  : " + this.LN + "<br>Age : " + this.Age + "<br>Height : " + this.Height);
        this.walk();
        this.Talk();
        this.Run();
        document.write("<br>*****************************************<br>");
    }
}
class Employee extends Human {
    constructor(EmployeeId, Department, Salary, DoJoing, FN, LN, Age, Height) {
        super(FN, LN, Age, Height);
        this.EmployeeId = EmployeeId;
        this.Department = Department;
        this.Salary = Salary;
        this.DoJoing = DoJoing;
    }
    Code() {
        document.write("<br>Coder Employee......!!!!!!!!<br>");
    }
    ReviewCode() {
        document.write("<br>Reviw code .....!!!!!!!!<br>");
    }
    ApplyForLeave() {
        document.write("<br>Employee Apply For Leave......!!!!!!!!<br>");
    }
    ShowDetails() {
        document.write("<br>First Name : " + this.FN + "<br>Last Name  : " + this.LN + "<br>Age : " + this.Age + "<br>Height : " + this.Height + "<br>Employee Id : " + this.EmployeeId + "<br>Department  : " + this.Department + "<br>Salary : " + this.Salary + "<br>Date Of Joining : " + this.DoJoing);
        this.Code();
        this.ReviewCode();
        this.ApplyForLeave();
        document.write("<br>*****************************************<br>");
    }
}
class Manager extends Employee {
    constructor(ManagerOfTeam, EmployeeId, Department, Salary, DoJoing, FN, LN, Age, Height) {
        super(EmployeeId, Department, Salary, DoJoing, FN, LN, Age, Height);
        this.ManagerOfTeam = ManagerOfTeam;
    }
    GenerateReport() {
        document.write("<br>Report Generated......!!!!!<br>");
    }
    AssignTasksToTeamMembers() {
        document.write("<brTasks Assigned......!!!!!<br>");
    }
    ApproveLeave() {
        document.write("<br>Leave Approved.....!!!!!<br>");
    }
    ShowDetails() {
        document.write("<br>First Name : " + this.FN + "<br>Last Name  : " + this.LN + "<br>Age : " + this.Age + "<br>Height : " + this.Height + "<br>Employee Id : " + this.EmployeeId + "<br>Department  : " + this.Department + "<br>Salary : " + this.Salary + "<br>Manager Of Team : " + this.ManagerOfTeam);
        this.GenerateReport();
        this.AssignTasksToTeamMembers();
        this.ApproveLeave();
        document.write("<br>*****************************************<br>");
    }
}
var h1 = new Human("Dnyanda", "Deshapnde", 21, 5.4);
h1.ShowDetails();
var e1 = new Employee(1234, "JS", 1000, "13/06/2018", "Akshay", "Deshapnde", 21, 6);
e1.ShowDetails();
var m1 = new Manager("XYZ", 87895, "JS", 200000, "13/06/2018", "Amit", "Deshapnde", 30, 5.9);
m1.ShowDetails();
var sm1 = {
    realName: "Amitabh Bachaan",
    superName: "Big B"
};
document.write("<br><br>" + sm1.realName + " is " + sm1.superName);
var superHeros = [];
superHeros.push({ realName: "Gangandhar", superName: "Shaktiman" }, { realName: "shinchan", superName: "ActionKame" });
for (var i = 0; i < superHeros.length; i++) {
    document.write("<br><br>" + superHeros[i].realName + "  " + superHeros[i].superName);
}
