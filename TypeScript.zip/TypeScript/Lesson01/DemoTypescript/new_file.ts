
let empName:string;
let empId: number;